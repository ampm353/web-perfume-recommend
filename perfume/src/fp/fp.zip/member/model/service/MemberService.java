package fp.member.model.service;

import java.sql.Connection;

import fp.common.JDBCTemplate;
import fp.member.model.dao.MemberDao;
import fp.member.model.vo.Member;

public class MemberService {

	public Member login(String memberId, String memberPw) {
		Connection conn = JDBCTemplate.getConnection();
		MemberDao dao = new MemberDao();
		Member m = dao.login(conn, memberId, memberPw);
		JDBCTemplate.close(conn);
		return m;	
	}

}
