package fp.member.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import fp.common.JDBCTemplate;

import fp.member.model.vo.Member;

public class MemberDao {

	public Member login(Connection conn, String memberId, String memberPw) {
		Member m = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String query = "select * from member where member_id = ? and member_pw = ? and member_valid='false'";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, memberId);
			pstmt.setString(2, memberPw);
			rset = pstmt.executeQuery();
			if(rset.next()) {
				m = new Member();
				m.setMemberNo(rset.getInt("member_no"));
				m.setMemberId(rset.getString("member_id"));
				m.setMemberNickname(rset.getString("member_nickname"));
				m.setMemberPw(rset.getString("member_pw"));
				m.setMemberGender(rset.getString("member_gender"));
				m.setMemberBirth(rset.getString("member_birth"));
				m.setMemberPhone(rset.getString("member_phone"));
				m.setMemberEnrollDate(rset.getDate("member_enroll_date"));
				m.setMemberValid(rset.getString("member_valid"));
				m.setMemberDeleteDate(rset.getDate("member_delete_date"));
				m.setMemberDeleteContent(rset.getString("member_delete_content"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		return m;
	}

}
